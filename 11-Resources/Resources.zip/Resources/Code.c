#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/i2c_host/i2c1.h"
#include <xc.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// =========================
// PROTOCOL CONSTANTS
// =========================
#define PREFIX1 'A'
#define PREFIX2 'Z'
#define SUFFIX1 'Y'
#define SUFFIX2 'B'

#define MY_ID    'T'
#define TEAM_IDS "CVKT"   // valid team IDs (C, V, K, T)

#define MAX_PAYLOAD 60

// =========================
// RX STATE MACHINE VARIABLES
// =========================
static uint8_t rx_state = 0;
static char    rx_from  = 0;
static char    rx_to    = 0;
static char    rx_payload[MAX_PAYLOAD];
static uint8_t rx_len   = 0;

// =========================
// SEND FRAME
// On the wire:
//   'A' 'Z' FROM TO PAYLOAD... 'Y' 'B'
// Example you want:
//   AZ T C hello YB
//   AZ K T hello YB
// =========================
void Send_Frame(char from, char to, const char *payload)
{
    // ============================
    // PRINT FULL MESSAGE TO DV
    // ============================
    char debugStr[100];
    sprintf(debugStr, "AZ%c%c%sYB\r\n", from, to, payload);
    printf("%s", debugStr);   // <-- DV now shows EXACT message

    // ============================
    // SEND FRAME OVER UART
    // ============================
    IO_RE1_SetHigh();   // BLUE LED = sending

    UART1_Write('A');
    UART1_Write('Z');

    UART1_Write(from);
    UART1_Write(to);

    for (uint8_t i = 0; payload[i] != '\0'; i++)
    {
        UART1_Write(payload[i]);
    }

    UART1_Write('Y');
    UART1_Write('B');

    __delay_ms(40);
    IO_RE1_SetLow();
}

// =========================
// READ HALL EFFECT SENSOR
// =========================
uint8_t Hall_ReadAngle(void)
{
    uint8_t regAngle = 0x0E;
    uint8_t read_angle_data[2];

    // Write register address
    I2C1_Host.Write(0x36, &regAngle, 1);
    __delay_ms(1);

    // Read 1 byte angle
    I2C1_Host.Read(0x36, read_angle_data, 1);
    __delay_ms(1);

    return read_angle_data[0];
}

// =========================
// HANDLE A COMPLETE RECEIVED FRAME
// Called when AZ from to payload YB is fully parsed
// =========================
/*
void Handle_Received_Frame(void)
{
    // Null-terminate payload for safety
    if (rx_len >= MAX_PAYLOAD)
        rx_len = MAX_PAYLOAD - 1;
    rx_payload[rx_len] = '\0';

    // RED LED = any valid message received FOR ME (rx_to == 'T')
    if (rx_to == MY_ID)
    {
        IO_RA5_SetHigh();
        __delay_ms(150);
        IO_RA5_SetLow();

        // ============================
        // PAYLOAD INTERPRETATION
        // ============================
        // 'R' = request Hall data (e.g. AZ C T R YB)
        if (rx_payload[0] == 'R')
        {
            // Read current Hall angle
            uint8_t angle = Hall_ReadAngle();

            // Build "H<angle>" payload (e.g. H123)
            char msg[8];
            sprintf(msg, "H%u", angle);

            // Send back to the requester (rx_from)
            // Example on wire: AZ T C H123 YB
            Send_Frame(MY_ID, rx_from, msg);
        }
        // 'H' = Hall data from someone else (e.g. AZ C T H123 YB)
        else if (rx_payload[0] == 'H')
        {
            printf("Received Hall data from %c: %s\r\n", rx_from, rx_payload);
        }
        else
        {
            // Other payload types can be handled here
            printf("Received msg from %c to %c: %s\r\n", rx_from, rx_to, rx_payload);
        }
    }
    else
    {
        // ============================
        // NOT FOR ME ? FORWARD
        // Example:
        //   In:  AZ C V hello YB
        //   Out: AZ C V hello YB  (unchanged)
        // ============================
        IO_RE1_SetHigh();  // BLUE LED while forwarding
        Send_Frame(rx_from, rx_to, rx_payload);
        IO_RE1_SetLow();
    }
}
*/
void Handle_Received_Frame(void)
{
    // Null-terminate payload
    if (rx_len >= MAX_PAYLOAD)
        rx_len = MAX_PAYLOAD - 1;
    rx_payload[rx_len] = '\0';

    // ============================
    // PRINT RAW MESSAGE TO DV
    // ============================
    printf("RX RAW: AZ%c%c%sYB\r\n", rx_from, rx_to, rx_payload);

    // ============================
    // ALWAYS FLASH RED LED ON RECEIVE
    // ============================
    IO_RA5_SetHigh();
    __delay_ms(500);
    IO_RA5_SetLow();

    // ============================
    // DO NOT PROCESS ANYTHING
    // DO NOT FORWARD ANYTHING
    // ============================
}

// =========================
// POLLED UART RX PARSER
// Call this often in main loop
// =========================
void UART_Poll_Receive(void)
{
    while (UART1_IsRxReady())
    {
        uint8_t c = UART1_Read();
        printf("Recieved Message: %3u\r\n", c);
        IO_RA5_Toggle();
        __delay_ms(500);
         IO_RA5_SetLow();
        switch (rx_state)
        {
            case 0:
                if (c == PREFIX1) rx_state = 1;
                break;

            case 1:
                if (c == PREFIX2) rx_state = 2;
                else rx_state = 0;
                break;

            case 2:
                rx_from = (char)c;   // FROM ID (must be in "CVKT")
                rx_state = 3;
                break;

            case 3:
                rx_to = (char)c;     // TO ID (must be in "CVKT")
                rx_len = 0;
                rx_state = 4;
                break;

            case 4:
                if (c == SUFFIX1)
                {
                    rx_state = 5;
                }
                else
                {
                    if (rx_len < MAX_PAYLOAD - 1)
                    {
                        rx_payload[rx_len++] = (char)c;
                    }
                }
                break;

            case 5:
                if (c == SUFFIX2)
                {
                    // Full frame received: AZ from to payload YB
                    Handle_Received_Frame();
                }
                rx_state = 0;
                break;

            default:
                rx_state = 0;
                break;
        }
    }
}

// =========================
// MAIN
// =========================
int main(void)
{
    SYSTEM_Initialize();
    I2C1_Initialize();
    UART1_Initialize();

    // Configure LEDs as outputs (if not already)
    IO_RA5_SetDigitalOutput();   // RED
    IO_RE1_SetDigitalOutput();   // BLUE
    IO_RE0_SetDigitalOutput();   // WHITE
     //IO_RA5_SetHigh();
    IO_RA5_SetLow();
    IO_RE1_SetLow();
    IO_RE0_SetLow();

    INTERRUPT_GlobalInterruptEnable();   // fine even though we poll
    
    // ============================
// SELF-TEST: simulate receiving AZTTtestYB
// ============================


    uint32_t counter = 0;

    while (1)
    {
       // IO_RA5_SetHigh();
        // ============================
        // 1) READ HALL SENSOR
        // ============================
        uint8_t angle = Hall_ReadAngle();
        //printf("Hall angle: %3u\r\n", angle);

        // WHITE LED = angle out of range (example thresholds)
        if (angle > 200 || angle < 10)
        {
            IO_RE0_SetHigh();
            __delay_ms(100);
            IO_RE0_SetLow();
        }

        // ============================
        // 2) PERIODIC HALL DATA SEND
        //    Send to EACH teammate using:
        //      AZ T C H<angle> YB
        //      AZ T V H<angle> YB
        //      AZ T K H<angle> YB
        //    (You can include or skip sending to yourself)
        // ============================
        static uint16_t sendTimer = 0;
        sendTimer += 200;   // loop delay is 200 ms

        if (sendTimer >= 1000)
        {
            sendTimer = 0;

            char payload[8];
            sprintf(payload, "H%u", angle);

            for (uint8_t i = 0; TEAM_IDS[i] != '\0'; i++)
            {
                char dest = TEAM_IDS[i];
                Send_Frame(MY_ID, dest, payload);
            }
        }


        // ============================
        // 3) POLL UART FOR INCOMING FRAMES
        // ============================
        UART_Poll_Receive();

        __delay_ms(200);
        counter++;
    }
}


